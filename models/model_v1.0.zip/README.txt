======================================================================
mlsubtype Model Bundle
======================================================================

Bundle Created: 2026-01-13T13:52:40.371728
Package Version: 0.1.0
Run ID: adfa02d6-f683-4681-9b2b-3a4319ffdf1c
Task Type: meta

----------------------------------------------------------------------
Contents
----------------------------------------------------------------------

Core Files:
  - run.json:       Training manifest with run_id, data lineage, config
  - artifacts.json: Registry of model artifacts in this bundle
  - version.txt:    Package version used for training
  - README.txt:     This file

Model Artifacts:
  - fold1/:  14 artifact(s)
  - fold2/:  14 artifact(s)
  - fold3/:  14 artifact(s)

----------------------------------------------------------------------
Usage
----------------------------------------------------------------------

Command-line inference:
  mlsubtype infer --bundle model_bundle.zip --data-csv test.csv --outdir results/

Python API:
  from mlsubtype.bundles import load_bundle
  bundle = load_bundle('model_bundle.zip')
  predictions = bundle.predict(X)

----------------------------------------------------------------------
Training Information
----------------------------------------------------------------------

Training Data: data/iris_data.csv
Data Hash: 5cd9f5a8a2823f0d9e964d3250bb60c03e2f2a576f9cc4c41bbe6e1b78427d6e
Data Rows: 150
Timestamp: 2026-01-13T13:49:40.350825

----------------------------------------------------------------------
Description
----------------------------------------------------------------------

Test model v1.0

----------------------------------------------------------------------
For more information:
  https://github.com/alexmarkowitz/mlsubtype
======================================================================