======================================================================
classiflow Model Bundle
======================================================================

Bundle Created: 2026-02-14T19:42:15.600764
Package Version: 0.1.0
Run ID: 2c983d5aef8b
Task Type: multiclass

----------------------------------------------------------------------
Contents
----------------------------------------------------------------------

Core Files:
  - run.json:       Training manifest with run_id, data lineage, config
  - training_config.json: Training config (hierarchical runs)
  - inference_config.json: Inference config (optional)
  - artifacts.json: Registry of model artifacts in this bundle
  - version.txt:    Package version used for training
  - README.txt:     This file

Model Artifacts:
  - fold1/:  4 artifact(s)

----------------------------------------------------------------------
Usage
----------------------------------------------------------------------

Command-line inference:
  classiflow infer --bundle model_bundle.zip --data-csv test.csv --outdir results/

Python API:
  from classiflow.bundles import load_bundle
  bundle = load_bundle('model_bundle.zip')
  predictions = bundle.predict(X)

----------------------------------------------------------------------
Training Information
----------------------------------------------------------------------

Training Data: /home/sagemaker-user/data/classiflow_data/CNS_FULL_DATASET_FAMILY_TRAIN.parquet
Data Hash: 002b9eb04b32940e860ec929cabcf54639263d4a3df2d8206f67b939e7dee739
Data Rows: 7372
Timestamp: 2026-02-14T19:42:15.475500

----------------------------------------------------------------------
Description
----------------------------------------------------------------------

Final model trained from scratch on 7372 samples

----------------------------------------------------------------------
For more information:
  https://github.com/alexmarkowitz/classiflow
======================================================================