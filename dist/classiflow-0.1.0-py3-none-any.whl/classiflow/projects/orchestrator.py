"""Orchestration for project workflows."""

from __future__ import annotations

import json
import logging
import platform
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import hashlib

import numpy as np
import pandas as pd
import joblib

from classiflow import __version__
from classiflow.config import TrainConfig, MetaConfig, HierarchicalConfig, MulticlassConfig
from classiflow.evaluation.smote_comparison import SMOTEComparison
from classiflow.inference import InferenceConfig, run_inference
from classiflow.lineage.manifest import TrainingRunManifest
from classiflow.lineage.hashing import compute_file_hash
from classiflow.models import get_estimators, AdaptiveSMOTE
from classiflow.tasks import TaskBuilder
from classiflow.training import train_binary_task, train_meta_classifier, train_multiclass_classifier
from classiflow.training.hierarchical_cv import train_hierarchical
from classiflow.models.torch_mlp import TorchMLPWrapper
from classiflow.projects.dataset_registry import verify_manifest_hash
from classiflow.projects.project_fs import ProjectPaths
from classiflow.projects.project_models import ProjectConfig, DatasetRegistry
from classiflow.projects.reporting import write_technical_report, write_test_report
from classiflow.projects.promotion import normalize_metric_name

logger = logging.getLogger(__name__)


def _git_hash(cwd: Path) -> Optional[str]:
    try:
        import subprocess
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            capture_output=True,
            text=True,
            timeout=2,
            cwd=cwd,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception:
        return None
    return None


def _config_hash(data: Dict) -> str:
    payload = json.dumps(data, sort_keys=True, default=str)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _run_id(phase: str, config_hash: str, train_hash: str, test_hash: Optional[str]) -> str:
    base = f"{phase}:{config_hash}:{train_hash}:{test_hash or ''}"
    return hashlib.sha256(base.encode("utf-8")).hexdigest()[:12]


def _resolve_manifest(project_root: Path, manifest_path: str) -> Path:
    path = Path(manifest_path)
    if not path.is_absolute():
        path = project_root / manifest_path
    return path


def _lineage_payload(
    phase: str,
    run_id: str,
    config_hash: str,
    train_hash: str,
    test_hash: Optional[str],
    command: str,
    args: Dict[str, str],
    root: Path,
    outputs: Optional[List[Path]] = None,
) -> Dict:
    timestamp_local = datetime.now().isoformat()
    timestamp_utc = datetime.now(timezone.utc).isoformat()
    payload = {
        "phase": phase,
        "run_id": run_id,
        "timestamp_local": timestamp_local,
        "timestamp_utc": timestamp_utc,
        "classiflow_version": __version__,
        "git_hash": _git_hash(root),
        "python_version": platform.python_version(),
        "platform": platform.platform(),
        "config_hash": config_hash,
        "dataset_hashes": {
            "train": train_hash,
            "test": test_hash,
        },
        "command": command,
        "args": args,
        "outputs": [],
    }
    if outputs:
        for item in outputs:
            if item.exists() and item.is_file():
                payload["outputs"].append(
                    {
                        "path": str(item),
                        "sha256": compute_file_hash(item),
                    }
                )
    return payload


def _load_registry(paths: ProjectPaths) -> DatasetRegistry:
    return DatasetRegistry.load(paths.datasets_yaml)


def _select_metric_column(df: pd.DataFrame, metric: str) -> Optional[str]:
    metric = normalize_metric_name(metric)
    for col in df.columns:
        if normalize_metric_name(col) == metric:
            return col
    return None


def _summarize_metrics_from_df(
    df: pd.DataFrame, metrics: List[str]
) -> Tuple[Dict[str, float], Dict[str, List[float]]]:
    summary: Dict[str, float] = {}
    per_fold: Dict[str, List[float]] = {}
    for metric in metrics:
        col = _select_metric_column(df, metric)
        if not col:
            continue
        values = df[col].dropna().astype(float).tolist()
        if not values:
            continue
        per_fold[metric] = values
        summary[normalize_metric_name(metric)] = float(np.mean(values))

    if summary:
        return summary, per_fold

    exclude_cols = {"fold", "phase", "task", "model_name", "sampler", "level"}
    numeric_cols = [
        col
        for col in df.columns
        if col not in exclude_cols and pd.api.types.is_numeric_dtype(df[col])
    ]
    for col in numeric_cols:
        values = df[col].dropna().astype(float).tolist()
        if not values:
            continue
        per_fold[col] = values
        summary[normalize_metric_name(col)] = float(np.mean(values))

    return summary, per_fold


def _technical_metrics_from_run(
    run_dir: Path, mode: str, metrics: List[str]
) -> Tuple[Dict[str, float], Dict[str, List[float]]]:
    if mode == "binary":
        metrics_path = run_dir / "metrics_outer_binary_eval.csv"
        df = pd.read_csv(metrics_path)
        df = df[df["phase"] == "val"]
        return _summarize_metrics_from_df(df, metrics)
    if mode == "meta":
        metrics_path = run_dir / "metrics_outer_meta_eval.csv"
        df = pd.read_csv(metrics_path)
        df = df[df["phase"] == "val"]
        return _summarize_metrics_from_df(df, metrics)
    if mode == "multiclass":
        metrics_path = run_dir / "metrics_outer_multiclass_eval.csv"
        df = pd.read_csv(metrics_path)
        df = df[df["phase"] == "val"]
        return _summarize_metrics_from_df(df, metrics)

    metrics_path = run_dir / "metrics_outer_eval.csv"
    df = pd.read_csv(metrics_path)
    df = df[df["level"].isin(["pipeline", "L1"])]
    return _summarize_metrics_from_df(df, metrics)


def run_technical_validation(
    paths: ProjectPaths,
    config: ProjectConfig,
    run_id: Optional[str] = None,
    compare_smote: bool = False,
) -> Path:
    """Run technical validation using project configuration."""
    registry = _load_registry(paths)
    train_entry = registry.datasets.get("train")
    test_entry = registry.datasets.get("test")
    if not train_entry:
        raise ValueError("Training dataset not registered")
    if train_entry.dirty or (test_entry and test_entry.dirty):
        raise ValueError("Dataset registry marked dirty; re-register before running validation")

    train_manifest = _resolve_manifest(paths.root, config.data.train.manifest)
    test_manifest = None
    if config.data.test is not None:
        test_manifest = _resolve_manifest(paths.root, config.data.test.manifest)

    if not verify_manifest_hash(train_manifest, train_entry.sha256):
        raise ValueError("Training manifest hash mismatch; re-register dataset")
    if test_entry and test_manifest and not verify_manifest_hash(test_manifest, test_entry.sha256):
        raise ValueError("Test manifest hash mismatch; re-register dataset")

    config_hash = _config_hash(config.model_dump(mode="python"))
    run_id = run_id or _run_id(
        "technical_validation",
        config_hash,
        train_entry.sha256,
        test_entry.sha256 if test_entry else None,
    )
    run_dir = paths.runs_subdir("technical_validation", run_id)
    run_dir.mkdir(parents=True, exist_ok=True)

    if config.task.mode == "binary":
        train_config = TrainConfig(
            data_csv=train_manifest,
            label_col=config.key_columns.label,
            outdir=run_dir,
            outer_folds=config.validation.nested_cv.outer_folds,
            inner_splits=config.validation.nested_cv.inner_folds,
            inner_repeats=config.validation.nested_cv.repeats,
            random_state=config.validation.nested_cv.seed,
            smote_mode="both" if config.imbalance.smote.get("compare") else (
                "on" if config.imbalance.smote.get("enabled") else "off"
            ),
        )
        train_binary_task(train_config)
    elif config.task.mode == "meta":
        train_config = MetaConfig(
            data_csv=train_manifest,
            label_col=config.key_columns.label,
            outdir=run_dir,
            outer_folds=config.validation.nested_cv.outer_folds,
            inner_splits=config.validation.nested_cv.inner_folds,
            inner_repeats=config.validation.nested_cv.repeats,
            random_state=config.validation.nested_cv.seed,
            smote_mode="both" if config.imbalance.smote.get("compare") else (
                "on" if config.imbalance.smote.get("enabled") else "off"
            ),
        )
        train_meta_classifier(train_config)
    elif config.task.mode == "multiclass":
        train_config = MulticlassConfig(
            data_csv=train_manifest,
            label_col=config.key_columns.label,
            outdir=run_dir,
            outer_folds=config.validation.nested_cv.outer_folds,
            inner_splits=config.validation.nested_cv.inner_folds,
            inner_repeats=config.validation.nested_cv.repeats,
            random_state=config.validation.nested_cv.seed,
            smote_mode="both" if config.imbalance.smote.get("compare") else (
                "on" if config.imbalance.smote.get("enabled") else "off"
            ),
        )
        train_multiclass_classifier(train_config)
    else:
        train_config = HierarchicalConfig(
            data_csv=train_manifest,
            patient_col=config.key_columns.patient_id if config.task.patient_stratified else None,
            label_l1=config.key_columns.label,
            label_l2=config.task.hierarchy_path,
            outdir=run_dir,
            outer_folds=config.validation.nested_cv.outer_folds,
            inner_splits=config.validation.nested_cv.inner_folds,
            random_state=config.validation.nested_cv.seed,
            use_smote=config.imbalance.smote.get("enabled", False),
            output_format="csv",
        )
        train_hierarchical(train_config)

    if config.imbalance.smote.get("compare") or compare_smote:
        comparison = SMOTEComparison.from_directory(run_dir)
        report = comparison.generate_report()
        smote_dir = run_dir / "smote_comparison"
        comparison.save_report(report, smote_dir)
        comparison.create_all_plots(outdir=smote_dir)

    config_path = run_dir / "config.resolved.yaml"
    config.save(config_path)

    summary, per_fold = _technical_metrics_from_run(run_dir, config.task.mode, config.metrics.primary)
    report_dir = run_dir / "reports"
    write_technical_report(report_dir, summary, per_fold, notes=[])

    lineage = _lineage_payload(
        phase="TECHNICAL_VALIDATION",
        run_id=run_id,
        config_hash=config_hash,
        train_hash=train_entry.sha256,
        test_hash=test_entry.sha256 if test_entry else None,
        command="classiflow project run-technical",
        args={"run_id": run_id},
        root=paths.root,
        outputs=[config_path],
    )
    with open(run_dir / "lineage.json", "w", encoding="utf-8") as handle:
        json.dump(lineage, handle, indent=2)

    metrics_path = run_dir / "metrics_summary.json"
    with open(metrics_path, "w", encoding="utf-8") as handle:
        json.dump({"summary": summary, "per_fold": per_fold}, handle, indent=2)

    return run_dir


def run_feasibility(
    paths: ProjectPaths,
    config: ProjectConfig,
    run_id: Optional[str] = None,
    classes: Optional[List[str]] = None,
    alpha: float = 0.05,
    min_n: int = 3,
    dunn_adjust: str = "holm",
    top_n: int = 30,
    write_legacy_csv: bool = True,
    write_legacy_xlsx: bool = True,
    run_viz: bool = True,
    fc_thresh: float = 1.0,
    fc_center: str = "median",
    label_topk: int = 12,
    heatmap_topn: int = 30,
    fig_dpi: int = 160,
) -> Path:
    """Run feasibility stats + visualizations on the training dataset."""
    registry = _load_registry(paths)
    train_entry = registry.datasets.get("train")
    if not train_entry:
        raise ValueError("Training dataset not registered")
    if train_entry.dirty:
        raise ValueError("Dataset registry marked dirty; re-register before running feasibility")

    train_manifest = _resolve_manifest(paths.root, config.data.train.manifest)
    if not verify_manifest_hash(train_manifest, train_entry.sha256):
        raise ValueError("Training manifest hash mismatch; re-register dataset")

    feasibility_options = {
        "classes": classes,
        "alpha": alpha,
        "min_n": min_n,
        "dunn_adjust": dunn_adjust,
        "top_n": top_n,
        "write_legacy_csv": write_legacy_csv,
        "write_legacy_xlsx": write_legacy_xlsx,
        "run_viz": run_viz,
        "fc_thresh": fc_thresh,
        "fc_center": fc_center,
        "label_topk": label_topk,
        "heatmap_topn": heatmap_topn,
        "fig_dpi": fig_dpi,
    }
    config_hash = _config_hash({
        "project": config.model_dump(mode="python"),
        "feasibility": feasibility_options,
    })
    run_id = run_id or _run_id("feasibility", config_hash, train_entry.sha256, None)
    run_dir = paths.runs_subdir("feasibility", run_id)
    run_dir.mkdir(parents=True, exist_ok=True)

    from classiflow.stats import run_stats, run_visualizations

    stats_results = run_stats(
        data_csv=train_manifest,
        label_col=config.key_columns.label,
        outdir=run_dir,
        classes=classes,
        alpha=alpha,
        min_n=min_n,
        dunn_adjust=dunn_adjust,
        top_n_features=top_n,
        write_legacy_csv=write_legacy_csv,
        write_legacy_xlsx=write_legacy_xlsx,
    )

    viz_results = None
    if run_viz:
        viz_results = run_visualizations(
            data_csv=train_manifest,
            label_col=config.key_columns.label,
            outdir=run_dir,
            stats_dir=stats_results["stats_dir"],
            classes=classes,
            alpha=alpha,
            fc_thresh=fc_thresh,
            fc_center=fc_center,
            label_topk=label_topk,
            heatmap_topn=heatmap_topn,
            fig_dpi=fig_dpi,
        )

    config_path = run_dir / "feasibility_config.json"
    with open(config_path, "w", encoding="utf-8") as handle:
        json.dump(
            {
                "data_csv": str(train_manifest),
                "label_col": config.key_columns.label,
                "run_viz": run_viz,
                "stats_options": feasibility_options,
                "stats_outputs": {
                    "stats_dir": str(stats_results.get("stats_dir")),
                    "publication_xlsx": str(stats_results.get("publication_xlsx")),
                    "legacy_xlsx": str(stats_results.get("legacy_xlsx")) if stats_results.get("legacy_xlsx") else None,
                },
                "viz_outputs": {
                    "viz_dir": str(viz_results.get("viz_dir")) if viz_results else None,
                },
            },
            handle,
            indent=2,
        )

    metrics_path = run_dir / "metrics_summary.json"
    with open(metrics_path, "w", encoding="utf-8") as handle:
        json.dump(
            {
                "summary": {
                    "n_samples": stats_results["n_samples"],
                    "n_features": stats_results["n_features"],
                    "n_classes": stats_results["n_classes"],
                },
                "per_fold": {},
            },
            handle,
            indent=2,
        )

    outputs = [config_path, metrics_path, stats_results["publication_xlsx"]]
    if stats_results.get("legacy_xlsx"):
        outputs.append(stats_results["legacy_xlsx"])

    lineage = _lineage_payload(
        phase="FEASIBILITY",
        run_id=run_id,
        config_hash=config_hash,
        train_hash=train_entry.sha256,
        test_hash=None,
        command="classiflow project run-feasibility",
        args={"run_id": run_id},
        root=paths.root,
        outputs=outputs,
    )
    with open(run_dir / "lineage.json", "w", encoding="utf-8") as handle:
        json.dump(lineage, handle, indent=2)

    return run_dir


def _select_best_binary_config(metrics_path: Path, selection_metric: str, direction: str) -> Dict[str, str]:
    df = pd.read_csv(metrics_path)
    metric_col = _select_metric_column(df, selection_metric)
    if metric_col is None:
        metric_col = "mean_test_score" if "mean_test_score" in df.columns else "mean_test_f1"
    df = df.dropna(subset=[metric_col])
    sort_asc = direction == "min"
    df = df.sort_values(metric_col, ascending=sort_asc)
    best = df.iloc[0]
    params = {
        k: best[k]
        for k in df.columns
        if k
        not in {
            "fold",
            "sampler",
            "task",
            "model_name",
            "rank_test_score",
            "rank_test_f1",
            "mean_test_f1",
            "std_test_f1",
            "mean_test_score",
            "std_test_score",
            metric_col,
        }
    }
    return {
        "model_name": best["model_name"],
        "sampler": best.get("sampler", "none"),
        "params": params,
    }


def _select_best_multiclass_config(metrics_path: Path, selection_metric: str, direction: str) -> Dict[str, str]:
    df = pd.read_csv(metrics_path)
    metric_col = _select_metric_column(df, selection_metric)
    if metric_col is None:
        metric_col = "mean_test_f1_macro" if "mean_test_f1_macro" in df.columns else "mean_test_score"
    df = df.dropna(subset=[metric_col])
    sort_asc = direction == "min"
    df = df.sort_values(metric_col, ascending=sort_asc)
    best = df.iloc[0]
    params = {
        k: best[k]
        for k in df.columns
        if k
        not in {
            "fold",
            "sampler",
            "task",
            "model_name",
            "rank_test_f1_macro",
            "mean_test_f1_macro",
            "std_test_f1_macro",
            "mean_test_score",
            "std_test_score",
            metric_col,
        }
    }
    return {
        "model_name": best["model_name"],
        "sampler": best.get("sampler", "none"),
        "params": params,
    }


def _filter_model_params(estimator, params: Dict[str, object]) -> Dict[str, object]:
    valid = set(estimator.get_params().keys())
    cleaned: Dict[str, object] = {}
    for key, value in params.items():
        if key not in valid:
            continue
        if value != value:
            continue
        cleaned[key] = value
    return cleaned


def _train_final_binary(
    config: ProjectConfig,
    train_manifest: Path,
    outdir: Path,
    best_cfg: Dict[str, str],
) -> None:
    from classiflow.io import load_data

    X, y_raw = load_data(train_manifest, config.key_columns.label)
    pos_label = y_raw.value_counts().idxmin()
    y = (y_raw == pos_label).astype(int)

    estimator = get_estimators(config.validation.nested_cv.seed, 10000)[best_cfg["model_name"]]
    cleaned = _filter_model_params(estimator, best_cfg["params"])
    params = {f"clf__{k}": v for k, v in cleaned.items() if k}
    sampler = AdaptiveSMOTE(k_max=5, random_state=config.validation.nested_cv.seed)
    if best_cfg.get("sampler") == "none":
        sampler = "passthrough"

    from sklearn.preprocessing import StandardScaler
    from imblearn.pipeline import Pipeline as ImbPipeline

    pipe = ImbPipeline([
        ("sampler", sampler),
        ("scaler", StandardScaler()),
        ("clf", estimator),
    ])
    if params:
        pipe.set_params(**params)
    pipe.fit(X, y)

    fold_dir = outdir / "fold1" / f"binary_{'smote' if best_cfg.get('sampler') == 'smote' else 'none'}"
    fold_dir.mkdir(parents=True, exist_ok=True)
    joblib.dump({"pipes": {"binary_task__" + best_cfg["model_name"]: pipe}, "best_models": {"binary_task": best_cfg["model_name"]}}, fold_dir / "binary_pipes.joblib")


def _train_final_meta(
    config: ProjectConfig,
    train_manifest: Path,
    outdir: Path,
    best_cfg: Dict[str, str],
) -> None:
    from classiflow.io import load_data

    X_full, y_full = load_data(train_manifest, config.key_columns.label)
    classes = sorted(y_full.unique().tolist())
    task_builder = TaskBuilder(classes).build_all_auto_tasks()
    tasks = task_builder.get_tasks()

    estimator = get_estimators(config.validation.nested_cv.seed, 10000)[best_cfg["model_name"]]
    cleaned = _filter_model_params(estimator, best_cfg["params"])
    params = {f"clf__{k}": v for k, v in cleaned.items() if k}
    sampler = AdaptiveSMOTE(k_max=5, random_state=config.validation.nested_cv.seed)
    if best_cfg.get("sampler") == "none":
        sampler = "passthrough"

    from sklearn.preprocessing import StandardScaler
    from imblearn.pipeline import Pipeline as ImbPipeline

    best_pipes = {}
    best_models = {}

    for task_name, task_func in tasks.items():
        y_bin = task_func(y_full).dropna()
        if y_bin.nunique() < 2:
            continue
        X_bin = X_full.loc[y_bin.index]
        pipe = ImbPipeline([
            ("sampler", sampler),
            ("scaler", StandardScaler()),
            ("clf", estimator),
        ])
        if params:
            pipe.set_params(**params)
        pipe.fit(X_bin, y_bin)
        best_pipes[f"{task_name}__{best_cfg['model_name']}"] = pipe
        best_models[task_name] = best_cfg["model_name"]

    from classiflow.training.meta import _build_meta_features
    from sklearn.linear_model import LogisticRegression

    X_meta = _build_meta_features(X_full, y_full, best_pipes, best_models, tasks)
    meta_model = LogisticRegression(
        class_weight="balanced",
        max_iter=10000,
        random_state=config.validation.nested_cv.seed,
    )
    meta_model.fit(X_meta.values, y_full.values)

    variant = "smote" if best_cfg.get("sampler") == "smote" else "none"
    fold_dir = outdir / "fold1" / f"binary_{variant}"
    fold_dir.mkdir(parents=True, exist_ok=True)

    joblib.dump({"pipes": best_pipes, "best_models": best_models}, fold_dir / "binary_pipes.joblib")
    joblib.dump(meta_model, fold_dir / "meta_model.joblib")
    pd.Series(list(X_meta.columns)).to_csv(fold_dir / "meta_features.csv", index=False, header=False)
    pd.Series(list(meta_model.classes_)).to_csv(fold_dir / "meta_classes.csv", index=False, header=False)


def _train_final_multiclass(
    config: ProjectConfig,
    train_manifest: Path,
    outdir: Path,
    best_cfg: Dict[str, str],
) -> None:
    from classiflow.io import load_data

    X_full, y_full = load_data(train_manifest, config.key_columns.label)
    classes = sorted(y_full.unique().tolist())

    estimator = get_estimators(config.validation.nested_cv.seed, 10000)[best_cfg["model_name"]]
    cleaned = _filter_model_params(estimator, best_cfg["params"])
    params = {f"clf__{k}": v for k, v in cleaned.items() if k}
    sampler = AdaptiveSMOTE(k_max=5, random_state=config.validation.nested_cv.seed)
    if best_cfg.get("sampler") == "none":
        sampler = "passthrough"

    from sklearn.preprocessing import StandardScaler
    from imblearn.pipeline import Pipeline as ImbPipeline

    pipe = ImbPipeline([
        ("sampler", sampler),
        ("scaler", StandardScaler()),
        ("clf", estimator),
    ])
    if params:
        pipe.set_params(**params)
    pipe.fit(X_full, y_full)

    variant = "smote" if best_cfg.get("sampler") == "smote" else "none"
    fold_dir = outdir / "fold1" / f"multiclass_{variant}"
    fold_dir.mkdir(parents=True, exist_ok=True)

    joblib.dump(pipe, fold_dir / "multiclass_model.joblib")
    (fold_dir / "multiclass_model_name.txt").write_text(best_cfg["model_name"])
    pd.Series(classes).to_csv(fold_dir / "classes.csv", index=False, header=False)
    pd.Series(list(X_full.columns)).to_csv(fold_dir / "feature_list.csv", index=False, header=False)


def _train_final_hierarchical(
    config: ProjectConfig,
    train_manifest: Path,
    outdir: Path,
    metrics_path: Path,
) -> None:
    import json as jsonlib
    import numpy as np
    from sklearn.preprocessing import LabelEncoder, StandardScaler
    from sklearn.model_selection import StratifiedShuffleSplit
    from classiflow.models.smote import apply_smote

    df = pd.read_csv(train_manifest)
    label_l1 = config.key_columns.label
    label_l2 = config.task.hierarchy_path
    if label_l2 is None:
        raise ValueError("hierarchy_path required for hierarchical final model")

    X_all = df.select_dtypes(include=[np.number]).values
    y_l1_all = df[label_l1].astype(str).values
    y_l2_all = df[label_l2].astype(str).values

    le_l1 = LabelEncoder().fit(y_l1_all)
    y_l1_enc = le_l1.transform(y_l1_all)

    split = StratifiedShuffleSplit(n_splits=1, test_size=0.2, random_state=config.validation.nested_cv.seed)
    train_idx, val_idx = next(split.split(X_all, y_l1_enc))

    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_all[train_idx])
    X_val = scaler.transform(X_all[val_idx])

    l1_classes = le_l1.classes_.tolist()

    inner_df = pd.read_csv(metrics_path)
    l1_rows = inner_df[inner_df["level"] == "L1"]
    if l1_rows.empty:
        raise ValueError("No L1 hyperparameter results found")
    l1_rows = l1_rows.sort_values("mean_f1_macro", ascending=False)
    best_cfg_l1 = l1_rows.iloc[0]

    best_cfg = {
        "hidden_dims": jsonlib.loads(best_cfg_l1["hidden_dims"]) if isinstance(best_cfg_l1["hidden_dims"], str) else best_cfg_l1["hidden_dims"],
        "lr": float(best_cfg_l1["lr"]),
        "epochs": int(best_cfg_l1["epochs"]),
        "dropout": float(best_cfg_l1["dropout"]),
    }

    X_train_l1 = X_train
    y_train_l1 = y_l1_enc[train_idx]
    if config.imbalance.smote.get("enabled"):
        X_train_l1, y_train_l1 = apply_smote(
            X_train_l1, y_train_l1, 5, config.validation.nested_cv.seed
        )

    model_l1 = TorchMLPWrapper(
        input_dim=X_train.shape[1],
        num_classes=len(l1_classes),
        hidden_dims=best_cfg["hidden_dims"],
        lr=best_cfg["lr"],
        epochs=best_cfg["epochs"],
        dropout=best_cfg["dropout"],
        batch_size=256,
        early_stopping_patience=10,
        device="auto",
        random_state=config.validation.nested_cv.seed,
        verbose=1,
    )
    model_l1.fit(X_train_l1, y_train_l1, X_val, y_l1_enc[val_idx])

    fold_dir = outdir / "fold1"
    fold_dir.mkdir(parents=True, exist_ok=True)
    model_l1.save(fold_dir / "model_level1_fold1.pt")
    with open(fold_dir / "model_config_l1_fold1.json", "w", encoding="utf-8") as handle:
        jsonlib.dump(model_l1.get_config(), handle, indent=2)
    joblib.dump(scaler, fold_dir / "scaler.joblib")
    joblib.dump(le_l1, fold_dir / "label_encoder_l1.joblib")

    # L2 branch training
    if label_l2:
        for l1_value in l1_classes:
            mask = y_l1_all == l1_value
            if mask.sum() < 5:
                continue
            l2_values = y_l2_all[mask]
            le_l2 = LabelEncoder().fit(l2_values)

            l2_rows = inner_df[inner_df["level"] == f"L2_{l1_value}"]
            if l2_rows.empty:
                continue
            l2_rows = l2_rows.sort_values("mean_f1_macro", ascending=False)
            best_cfg_l2 = l2_rows.iloc[0]
            cfg_l2 = {
                "hidden_dims": jsonlib.loads(best_cfg_l2["hidden_dims"]) if isinstance(best_cfg_l2["hidden_dims"], str) else best_cfg_l2["hidden_dims"],
                "lr": float(best_cfg_l2["lr"]),
                "epochs": int(best_cfg_l2["epochs"]),
                "dropout": float(best_cfg_l2["dropout"]),
            }

            X_branch = scaler.transform(X_all[mask])
            y_branch = le_l2.transform(l2_values)

            split = StratifiedShuffleSplit(n_splits=1, test_size=0.2, random_state=config.validation.nested_cv.seed)
            tr_idx, va_idx = next(split.split(X_branch, y_branch))
            X_tr_b, X_va_b = X_branch[tr_idx], X_branch[va_idx]
            y_tr_b, y_va_b = y_branch[tr_idx], y_branch[va_idx]

            model_l2 = TorchMLPWrapper(
                input_dim=X_branch.shape[1],
                num_classes=len(le_l2.classes_),
                hidden_dims=cfg_l2["hidden_dims"],
                lr=cfg_l2["lr"],
                epochs=cfg_l2["epochs"],
                dropout=cfg_l2["dropout"],
                batch_size=256,
                early_stopping_patience=10,
                device="auto",
                random_state=config.validation.nested_cv.seed,
                verbose=1,
            )
            model_l2.fit(X_tr_b, y_tr_b, X_va_b, y_va_b)
            safe_l1 = l1_value.replace(" ", "_")
            model_l2.save(fold_dir / f"model_level2_{safe_l1}_fold1.pt")
            with open(fold_dir / f"model_config_l2_{safe_l1}_fold1.json", "w", encoding="utf-8") as handle:
                jsonlib.dump(model_l2.get_config(), handle, indent=2)
            joblib.dump(le_l2, fold_dir / f"label_encoder_l2_{safe_l1}.joblib")

    config_path = outdir / "training_config.json"
    with open(config_path, "w", encoding="utf-8") as handle:
        training_config = HierarchicalConfig(
            data_csv=train_manifest,
            patient_col=config.key_columns.patient_id if config.task.patient_stratified else None,
            label_l1=label_l1,
            label_l2=label_l2,
            outdir=outdir,
            outer_folds=1,
            inner_splits=config.validation.nested_cv.inner_folds,
            random_state=config.validation.nested_cv.seed,
        )
        jsonlib.dump(training_config.to_dict(), handle, indent=2)


def build_final_model(
    paths: ProjectPaths,
    config: ProjectConfig,
    technical_run: Path,
    run_id: Optional[str] = None,
) -> Path:
    registry = _load_registry(paths)
    train_entry = registry.datasets.get("train")
    test_entry = registry.datasets.get("test")
    if not train_entry:
        raise ValueError("Datasets not registered")

    train_manifest = _resolve_manifest(paths.root, config.data.train.manifest)

    config_hash = _config_hash(config.model_dump(mode="python"))
    run_id = run_id or _run_id(
        "final_model",
        config_hash,
        train_entry.sha256,
        test_entry.sha256 if test_entry else None,
    )
    run_dir = paths.runs_subdir("final_model", run_id)
    run_dir.mkdir(parents=True, exist_ok=True)

    metrics_path = technical_run / "metrics_inner_cv.csv"

    if config.task.mode in {"binary", "meta"}:
        best_cfg = _select_best_binary_config(
            metrics_path, config.models.selection_metric, config.models.selection_direction
        )
        if config.task.mode == "binary":
            _train_final_binary(config, train_manifest, run_dir, best_cfg)
        else:
            _train_final_meta(config, train_manifest, run_dir, best_cfg)
    elif config.task.mode == "multiclass":
        best_cfg = _select_best_multiclass_config(
            metrics_path, config.models.selection_metric, config.models.selection_direction
        )
        _train_final_multiclass(config, train_manifest, run_dir, best_cfg)
    else:
        _train_final_hierarchical(config, train_manifest, run_dir, metrics_path)

    manifest = TrainingRunManifest(
        run_id=run_id,
        timestamp=datetime.now().isoformat(),
        package_version=__version__,
        training_data_path=str(train_manifest),
        training_data_hash=train_entry.sha256,
        training_data_size_bytes=train_manifest.stat().st_size,
        training_data_row_count=train_entry.stats.rows,
        config=config.model_dump(mode="python"),
        task_type=config.task.mode,
        python_version=platform.python_version(),
        hostname=platform.node(),
        git_hash=_git_hash(paths.root),
        feature_list=train_entry.data_schema.feature_columns,
    )
    manifest.save(run_dir / "run.json")

    from classiflow.bundles.create import create_bundle

    bundle_path = create_bundle(run_dir, run_dir / "model_bundle")

    lineage = _lineage_payload(
        phase="FINAL_MODEL",
        run_id=run_id,
        config_hash=config_hash,
        train_hash=train_entry.sha256,
        test_hash=test_entry.sha256 if test_entry else None,
        command="classiflow project build-bundle",
        args={"run_id": run_id, "technical_run": technical_run.name},
        root=paths.root,
        outputs=[bundle_path, run_dir / "run.json"],
    )
    with open(run_dir / "lineage.json", "w", encoding="utf-8") as handle:
        json.dump(lineage, handle, indent=2)

    return run_dir


def run_independent_test(
    paths: ProjectPaths,
    config: ProjectConfig,
    bundle_path: Path,
    run_id: Optional[str] = None,
) -> Path:
    registry = _load_registry(paths)
    train_entry = registry.datasets.get("train")
    test_entry = registry.datasets.get("test")
    if not train_entry:
        raise ValueError("Training dataset not registered")
    if not test_entry or config.data.test is None:
        raise ValueError("Test dataset not registered or configured")

    if config.data.test is None:
        raise ValueError("Project has no test manifest configured")
    test_manifest = _resolve_manifest(paths.root, config.data.test.manifest)
    if not verify_manifest_hash(test_manifest, test_entry.sha256):
        raise ValueError("Test manifest hash mismatch; re-register dataset")

    config_hash = _config_hash(config.model_dump(mode="python"))
    run_id = run_id or _run_id("independent_test", config_hash, train_entry.sha256, test_entry.sha256)
    run_dir = paths.runs_subdir("independent_test", run_id)
    run_dir.mkdir(parents=True, exist_ok=True)

    from classiflow.bundles import load_bundle

    bundle_data = load_bundle(bundle_path, fold=1)
    try:
        infer_config = InferenceConfig(
            run_dir=bundle_data["fold_dir"],
            data_csv=test_manifest,
            output_dir=run_dir,
            id_col=config.key_columns.sample_id,
            label_col=config.key_columns.label,
            include_excel=True,
            include_plots=True,
            verbose=1,
        )
        results = run_inference(infer_config)
    finally:
        bundle_data["loader"].cleanup()

    metrics = results.get("metrics", {})
    metrics_path = run_dir / "metrics.json"
    with open(metrics_path, "w", encoding="utf-8") as handle:
        json.dump(metrics, handle, indent=2)

    summary_metrics = {}
    for key, value in metrics.items():
        if isinstance(value, (int, float)):
            summary_metrics[key] = float(value)
    if "overall" in metrics:
        for key, value in metrics["overall"].items():
            if isinstance(value, (int, float)):
                summary_metrics[key] = float(value)

    write_test_report(run_dir / "reports", summary_metrics, notes=[])

    lineage = _lineage_payload(
        phase="INDEPENDENT_TEST",
        run_id=run_id,
        config_hash=config_hash,
        train_hash=train_entry.sha256,
        test_hash=test_entry.sha256,
        command="classiflow project run-test",
        args={"run_id": run_id, "bundle": str(bundle_path)},
        root=paths.root,
        outputs=[metrics_path],
    )
    with open(run_dir / "lineage.json", "w", encoding="utf-8") as handle:
        json.dump(lineage, handle, indent=2)

    return run_dir
