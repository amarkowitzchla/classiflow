"""Command-line interface."""

from classiflow.cli.main import app

__all__ = ["app"]
