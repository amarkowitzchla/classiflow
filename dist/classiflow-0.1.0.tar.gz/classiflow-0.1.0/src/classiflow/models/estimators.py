"""Estimator registry and parameter grids."""

from __future__ import annotations

from typing import Dict, Any

from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier


def get_estimators(random_state: int = 42, max_iter: int = 10000) -> Dict[str, Any]:
    """
    Get dictionary of estimators with consistent configurations.

    Parameters
    ----------
    random_state : int
        Random seed for reproducibility
    max_iter : int
        Maximum iterations for iterative estimators

    Returns
    -------
    estimators : Dict[str, Any]
        Estimator name -> sklearn estimator instance
    """
    return {
        "LogisticRegression": LogisticRegression(
            penalty="l1",
            solver="saga",
            class_weight="balanced",
            max_iter=max_iter,
            random_state=random_state,
        ),
        "SVM": SVC(
            kernel="linear",
            class_weight="balanced",
            max_iter=max_iter,
            random_state=random_state,
            probability=True,
        ),
        "RandomForest": RandomForestClassifier(
            n_jobs=-1,
            class_weight="balanced",
            random_state=random_state,
        ),
        "GradientBoosting": GradientBoostingClassifier(
            random_state=random_state,
        ),
    }


def get_param_grids() -> Dict[str, Dict[str, list]]:
    """
    Get hyperparameter grids for GridSearchCV.

    Returns
    -------
    param_grids : Dict[str, Dict[str, list]]
        Estimator name -> parameter grid
    """
    return {
        "LogisticRegression": {
            "clf__C": [0.01, 0.1, 1, 10],
        },
        "SVM": {
            "clf__C": [0.01, 0.1, 1, 10],
        },
        "RandomForest": {
            "clf__n_estimators": [100, 200],
            "clf__max_depth": [None, 10, 20],
        },
        "GradientBoosting": {
            "clf__n_estimators": [100, 200],
            "clf__learning_rate": [0.01, 0.1],
            "clf__max_depth": [3, 5],
        },
    }
