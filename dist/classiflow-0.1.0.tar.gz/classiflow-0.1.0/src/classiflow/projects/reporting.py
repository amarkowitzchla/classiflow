"""Reporting utilities for project runs."""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List

import pandas as pd


def _write_markdown_table(df: pd.DataFrame) -> str:
    if df.empty:
        return "(no data)"
    try:
        return df.to_markdown(index=False)
    except Exception:
        return df.to_csv(index=False)


def write_technical_report(
    outdir: Path,
    metrics_summary: Dict[str, float],
    per_fold: Dict[str, List[float]],
    notes: List[str],
) -> Path:
    """Write a markdown technical validation report."""
    outdir.mkdir(parents=True, exist_ok=True)
    rows = []
    for metric, value in metrics_summary.items():
        rows.append({"metric": metric, "value": value})
    summary_df = pd.DataFrame(rows)

    fold_rows = []
    for metric, values in per_fold.items():
        for idx, value in enumerate(values, start=1):
            fold_rows.append({"metric": metric, "fold": idx, "value": value})
    fold_df = pd.DataFrame(fold_rows)

    md_lines = [
        "# Technical Validation Report",
        "",
        "## Summary Metrics",
        _write_markdown_table(summary_df),
        "",
        "## Per-fold Metrics",
        _write_markdown_table(fold_df),
    ]
    if notes:
        md_lines.extend(["", "## Notes"])
        md_lines.extend([f"- {note}" for note in notes])

    path = outdir / "technical_validation_report.md"
    path.write_text("\n".join(md_lines), encoding="utf-8")
    return path


def write_test_report(
    outdir: Path,
    metrics: Dict[str, float],
    notes: List[str],
) -> Path:
    """Write a markdown independent test report."""
    outdir.mkdir(parents=True, exist_ok=True)
    rows = [{"metric": metric, "value": value} for metric, value in metrics.items()]
    df = pd.DataFrame(rows)

    md_lines = [
        "# Independent Test Report",
        "",
        "## Metrics",
        _write_markdown_table(df),
    ]
    if notes:
        md_lines.extend(["", "## Notes"])
        md_lines.extend([f"- {note}" for note in notes])

    path = outdir / "independent_test_report.md"
    path.write_text("\n".join(md_lines), encoding="utf-8")
    return path


def write_promotion_report(
    outdir: Path,
    decision: bool,
    reasons: List[str],
    gate_table: pd.DataFrame,
) -> Path:
    """Write a markdown promotion report."""
    outdir.mkdir(parents=True, exist_ok=True)
    status = "PASS" if decision else "FAIL"
    md_lines = [
        "# Promotion Recommendation",
        "",
        f"**Decision:** {status}",
        "",
        "## Gate Evaluation",
        _write_markdown_table(gate_table),
    ]
    if reasons:
        md_lines.extend(["", "## Reasons"])
        md_lines.extend([f"- {reason}" for reason in reasons])

    path = outdir / "promotion_report.md"
    path.write_text("\n".join(md_lines), encoding="utf-8")
    return path
